//---------------------------------------------------------------------------

#pragma hdrstop

#include "SpellCheck.h"
#include <fstream>
#include <cctype>
//---------------------------------------------------------------------------
#pragma package(smart_init)



// Node creation
Node* node_creation(int w, std::string d) {
    Node* temp = new Node;
    temp->data = d;
    temp->right = nullptr;
    temp->left = nullptr;
    temp->weight_of_word = w;
    return temp;
}

// Calculate weight of the word
int calculateWeight(const std::string& word) {
    int weight = 0;
    for (char c : word) {
        weight += static_cast<int>(c); // Add ASCII value of each character
    }
    return weight;
}

// Insert word into the BST
Node* insert(Node*& root, int key, std::string word) {
    if (root == nullptr) {
        root = node_creation(key, word);
        return root;
    }
    if (key < root->weight_of_word) {
        root->left = insert(root->left, key, word);
    }
    else if (key > root->weight_of_word) {
        root->right = insert(root->right, key, word);
    }
    else {
        if (word < root->data) {
            root->left = insert(root->left, key, word);
        }
        else if (word > root->data) {
            root->right = insert(root->right, key, word);
        }
    }
    return root;
}

// Inorder traversal of BST
void inorderTraversal(Node* root) {
    if (root != nullptr) {
        inorderTraversal(root->left);
        ShowMessage(root->data.c_str());
        inorderTraversal(root->right);
    }
}

// Search for a word in the BST
bool search(Node* root, const std::string& word) {
    if (root == nullptr) {
        return false;
    }
    if (root->data == word) {
        return true;
    }
    else if (calculateWeight(word) * calculateWeight(word) < root->weight_of_word) {
        return search(root->left, word);
    }
    else {
        return search(root->right, word);
    }
}

// Load dictionary from file
void loaddictionary(Node*& root) {
    std::string word;
    std::ifstream inDict("dict.txt");
    if (!inDict) {
        ShowMessage("Error opening dict.txt");
        return;
    }
    while (getline(inDict, word)) {
        int weight = calculateWeight(word);
        weight = weight * weight;
        insert(root, weight, word);
    }
    inDict.close();
}

// Spell corrector
void spell_corrector(Node* root, std::string str22, TMemo* memo) {
    static std::string fin = "";
    int hit = 0;

    if (root != nullptr) {
        fin = root->data;

        if ((fin.size() - str22.size()) <= 2) {
            for (int o = 0; o < str22.size(); o++) {
                for (int i = 0; i < fin.size(); i++) {
                    if (str22[o] == fin[i]) {
                        hit++;
                        break;
                    }
                }
            }
        }

        int hitrate = (hit * 100) / str22.size();

        if (hitrate >= 50) {
            memo->Lines->Add(fin.c_str());
        }

        spell_corrector(root->left, str22, memo);
        spell_corrector(root->right, str22, memo);
    }
}

// User search method
void usersearchmethod(Node*& root, TMemo* memo, const std::string& word) {
    if (search(root, word)) {
        ShowMessage("Word '" + word + "' exists in the dictionary.");
    }
    else {
        ShowMessage("Word '" + word + "' does not exist in the dictionary. Showing suggestions:");
        spell_corrector(root, word, memo);
    }
}