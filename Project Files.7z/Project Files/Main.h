//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Objects.hpp>
#include <FMX.Types.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *BG;
	TRectangle *Title;
	TLabel *TitleText;
	TRectangle *Menu;
	TRadioButton *AddDictionary;
	TRadioButton *AddWord;
	TRadioButton *SearchWord;
	TRadioButton *ShowDictionary;
	TRadioButton *Exit;
	void __fastcall ExitChange(TObject *Sender);
	void __fastcall AddDictionaryChange(TObject *Sender);
	void __fastcall AddWordChange(TObject *Sender);
	void __fastcall SearchWordChange(TObject *Sender);
	void __fastcall ShowDictionaryChange(TObject *Sender);
private:	// User declarations

public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
extern struct node* root;
//---------------------------------------------------------------------------
#endif
