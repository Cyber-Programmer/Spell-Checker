//---------------------------------------------------------------------------

#ifndef ShowDictionaryH
#define ShowDictionaryH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ListBox.hpp>
#include <FMX.Objects.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
//---------------------------------------------------------------------------
class TForm5 : public TForm
{
__published:	// IDE-managed Components
	TImage *BG;
	TRectangle *Title;
	TLabel *TitleText;
	TRectangle *Menu;
	TButton *ShowButton;
	TButton *ExitButton;
	TListBox *WordList;
	void __fastcall ExitButtonClick(TObject *Sender);
	void __fastcall ShowButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm5(TComponent* Owner);
    void DisplayAllWords(struct node* root);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm5 *Form5;
//---------------------------------------------------------------------------
#endif
