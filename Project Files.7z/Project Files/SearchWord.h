//---------------------------------------------------------------------------

#ifndef SearchWordH
#define SearchWordH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Edit.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ListBox.hpp>
#include <FMX.Objects.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
//---------------------------------------------------------------------------
class TForm4 : public TForm
{
__published:	// IDE-managed Components
	TImage *BG;
	TRectangle *Title;
	TLabel *TitleText;
	TRectangle *Menu;
	TButton *SearchButton;
	TButton *ExitButton;
	TListBox *Result;
	TEdit *Input;
	void __fastcall ExitButtonClick(TObject *Sender);
	void __fastcall SearchButtonClick(TObject *Sender);
    void __fastcall ResultItemClick(TCustomListBox * const Sender, TListBoxItem * const Item);


private:	// User declarations
public:		// User declarations
	__fastcall TForm4(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm4 *Form4;
//---------------------------------------------------------------------------
#endif
