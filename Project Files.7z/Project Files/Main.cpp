//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Main.h"
#include "AddDictionary.h"
#include "AddWord.h"
#include "SearchWord.h"
#include "ShowDictionary.h"
#include "SpellCorrector.h"
// Global variable declaration
struct node* root = NULL;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitChange(TObject *Sender)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AddDictionaryChange(TObject *Sender)
{
	AddDictionary->IsChecked = false;
	this->Hide();
	Form2->Show();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AddWordChange(TObject *Sender)
{
	AddWord->IsChecked = false;
	this->Hide();
	Form3->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SearchWordChange(TObject *Sender)
{
	SearchWord->IsChecked = false;
	this->Hide();
	Form4->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ShowDictionaryChange(TObject *Sender)
{
	ShowDictionary->IsChecked = false;
	this->Hide();
	Form5->Show();
}
//---------------------------------------------------------------------------
