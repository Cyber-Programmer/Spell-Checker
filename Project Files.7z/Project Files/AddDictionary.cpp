//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "AddDictionary.h"
#include "Main.h"
#include "SpellCorrector.h"
#include "fstream"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::ExitButtonClick(TObject *Sender)
{
	this->Hide();
	Form1->Show();
    Result->Clear();
}
//---------------------------------------------------------------------------


void __fastcall TForm2::AddButtonClick(TObject *Sender)
{
    Result->Clear(); // Clear the list before adding new items

    ifstream dictFile("C:\\Users\\PMLS\\Documents\\Embarcadero\\Studio\\Projects\\dictionary.txt");
    if (!dictFile.is_open()) {
        Result->Items->Add("Error opening dictionary file for reading!");
        return;
    }

    string word;

	while (dictFile >> word) {
		bool found = false;
        vector<string> dummySuggestions; // Unused in this context
        search(root, calculate_word_weight(word), word, found, dummySuggestions);
        if (found) {
            duplicateCount += 1;
            Result->Items->Add("Duplicate word: " + String(word.c_str()));
        } else {
            root = insert(root, calculate_word_weight(word), word);
			Result->Items->Add("Added word: " + String(word.c_str()));
		}
		Application->ProcessMessages(); // Update the UI
	}

	dictFile.close();

	ShowMessage("Dictionary loaded successfully.\nWord count: " + IntToStr(word_count)+"\nDuplicate words skipped: " + IntToStr(duplicateCount));
}
//---------------------------------------------------------------------------

