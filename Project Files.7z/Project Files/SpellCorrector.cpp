//---------------------------------------------------------------------------

#pragma hdrstop

#include "SpellCorrector.h"
#include <iostream>
#include <cmath>
#include <algorithm>


// Initialize the global variable
int word_count = 0;
int duplicateCount = 0;
int calculate_word_weight(const string& word) {
    int weight = 0;
    for (char c : word) {
        weight += int(c) * int(c); // Add the ASCII value of each character
    }
    return weight;
}

struct node* node_creation(int w, string d) {
    struct node* temp = new node;
    temp->data = d;
    temp->weight_of_word = w;
    temp->left = temp->right = NULL;
    return temp;
}

struct node* insert(struct node* root, int key, string word) {
    if (root == NULL) {
        word_count++; // Increment word count when a new node is created
        return node_creation(key, word);
    }

    if (root->data == word) {
        return root;
    }

    if (root->weight_of_word > key) {
        root->left = insert(root->left, key, word);
    } else {
        root->right = insert(root->right, key, word);
    }

    return root;
}

void inorder_traversal(struct node* root, vector<string>& words) {
    if (root == NULL) {
        return;
    }
    inorder_traversal(root->left, words);
    words.push_back(root->data);
    inorder_traversal(root->right, words);
}

void spell_corrector(struct node* root, const string& str22, vector<string>& suggestions) {
    if (root == NULL) {
        return;
    }

    string fin = root->data;
    int hit = 0;

    if (abs(static_cast<int>(fin.size()) - static_cast<int>(str22.size())) <= 2) {
        for (size_t o = 0; o < min(fin.size(), str22.size()); o++) {
            if (fin[o] == str22[o]) {
                hit++;
            }
        }
    }

    int hitrate = ((hit * 100) / str22.size());
    if (hitrate >= 50) {
        suggestions.push_back(fin);
    }

    spell_corrector(root->left, str22, suggestions);
    spell_corrector(root->right, str22, suggestions);
}

void search(struct node* root, int ww, const string& str, bool& found, vector<string>& suggestions) {
    struct node* temp = root;

    while (root != NULL) {
        if (root->data == str) {
            found = true;
            return;
        } else if (root->weight_of_word < ww) {
            root = root->right;
        } else {
            root = root->left;
        }
    }

    if (!found) {
        spell_corrector(temp, str, suggestions);
    }
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
