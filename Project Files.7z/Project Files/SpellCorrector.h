//---------------------------------------------------------------------------

#ifndef SpellCorrectorH
#define SpellCorrectorH
#include <string>
#include <vector>
#include <cmath>
using namespace std;

// Node structure for the binary search tree
struct node {
    string data;
    int weight_of_word;
    struct node* right;
    struct node* left;
};

// Global variable to keep track of the number of words
extern int word_count;
extern int duplicateCount;
// Function declarations
int calculate_word_weight(const string& word);
struct node* node_creation(int w, string d);
struct node* insert(struct node* root, int key, string word);
void inorder_traversal(struct node* root, vector<string>& words);
void spell_corrector(struct node* root, const string& str22, vector<string>& suggestions);
void search(struct node* root, int ww, const string& str, bool& found, vector<string>& suggestions);





//---------------------------------------------------------------------------
#endif
