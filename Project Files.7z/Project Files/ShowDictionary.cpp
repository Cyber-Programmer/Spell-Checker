//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "ShowDictionary.h"
#include "Main.h"
#include "SpellCorrector.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm5 *Form5;
//---------------------------------------------------------------------------
__fastcall TForm5::TForm5(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm5::ExitButtonClick(TObject *Sender)
{
	this->Hide();
	Form1->Show();
    WordList->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm5::ShowButtonClick(TObject *Sender)
{
		 WordList->Clear(); // Clear the list before adding new items
	DisplayAllWords(root); // Use the global root variable
}
//---------------------------------------------------------------------------

void TForm5::DisplayAllWords(node* root) {
    if (root == NULL) {
		// Check if the root node is NULL and the tree is empty
        if (word_count == 0) {
            ShowMessage("Dictionary is Empty.");
        }
        return;
    }
    DisplayAllWords(root->left);
    WordList->Items->Add(root->data.c_str());
    DisplayAllWords(root->right);
}


