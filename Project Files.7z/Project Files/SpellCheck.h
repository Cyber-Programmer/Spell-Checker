//---------------------------------------------------------------------------

#ifndef SpellCheckH
#define SpellCheckH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Dialogs.hpp>
#include <string>

struct Node {
    std::string data;
    int weight_of_word;
    Node* right;
    Node* left;
};

// Function declarations
Node* node_creation(int w, std::string d);
int calculateWeight(const std::string& word);
Node* insert(Node*& root, int key, std::string word);
void inorderTraversal(Node* root);
bool search(Node* root, const std::string& word);
void loaddictionary(Node*& root);
void spell_corrector(Node* root, std::string str22, TMemo* memo);
void usersearchmethod(Node*& root, TMemo* memo, const std::string& word);




#endif
