//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "SearchWord.h"
#include "Main.h"
#include "SpellCorrector.h"
#include <fstream>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm4 *Form4;
//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm4::ExitButtonClick(TObject *Sender)
{
	this->Hide();
	Form1->Show();
    Input->Text = "";
    Input->TextPrompt = "Enter Word";
}
//---------------------------------------------------------------------------


void __fastcall TForm4::SearchButtonClick(TObject *Sender)
{
    Result->Clear(); // Clear the list before adding new items
	String searchWord = Input->Text;
    searchWord = searchWord.LowerCase();
    if (searchWord.IsEmpty()) {
        ShowMessage("Please enter a word.");
        return;
    }

    string searchWordStr = AnsiString(searchWord).c_str();
    int searchWordWeight = calculate_word_weight(searchWordStr);
    vector<string> suggestions;
    bool found = false;

    search(root, searchWordWeight, searchWordStr, found, suggestions);

    if (found) {
        ShowMessage("The word \"" + searchWord + "\" exists in the dictionary.");
    } else {
        ShowMessage("The word \"" + searchWord + "\" does not exist in the dictionary.");
		ShowMessage("Suggestions In The ListBox");
        Result->Items->Add(searchWord);
        for (const auto& suggestion : suggestions) {
            Result->Items->Add(suggestion.c_str());
        }
    }
}

//---------------------------------------------------------------------------


void __fastcall TForm4::ResultItemClick(TCustomListBox * const Sender, TListBoxItem * const Item)

{
       if (Item != NULL) {
        String selectedWord = Item->Text;
        // Check if the selected word is not empty
        if (!selectedWord.IsEmpty()) {
            // Add the selected word to the dictionary file
			ofstream dictFile("C:\\Users\\PMLS\\Documents\\Embarcadero\\Studio\\Projects\\dictionary.txt", ios::app);
			if (dictFile.is_open()) {
				int newWordWeight = calculate_word_weight(AnsiString(selectedWord).c_str());
				dictFile << "\n" << AnsiString(selectedWord).c_str(); // Ensure each word is inserted on a new line
				dictFile.close();
				root = insert(root, newWordWeight,AnsiString(selectedWord).c_str());
                ShowMessage("Word \"" + selectedWord + "\" added to the dictionary.");
                Input->Text = "";
                Result->Clear();
            } else {
                ShowMessage("Error opening dictionary file for writing!");
            }
        }
    }
}
//---------------------------------------------------------------------------

