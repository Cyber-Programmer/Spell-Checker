//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "AddWord.h"
#include "Main.h"
#include "SpellCorrector.h"
#include <fstream>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm3::ExitButtonClick(TObject *Sender)
{
	this->Hide();
	Form1->Show();
	Input->Text = "";
    ListBox1->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm3::AddButtonClick(TObject *Sender)
{
    ListBox1->Clear(); // Clear the list before adding new items
	String newWord = Input->Text;
    newWord = newWord.LowerCase();
    if (newWord.IsEmpty()) {
        ListBox1->Items->Add("Please enter a word.");
        return;
    }

    string newWordStr = AnsiString(newWord).c_str();
    int newWordWeight = calculate_word_weight(newWordStr);
    bool found = false;
    vector<string> dummySuggestions; // Unused in this context

    search(root, newWordWeight, newWordStr, found, dummySuggestions);

    if (found) {
		ShowMessage("The word \"" + newWord + "\" is already in the dictionary.");
		++duplicateCount;
	} else {
		root = insert(root, newWordWeight, newWordStr);
		ofstream dictFile("C:\\Users\\PMLS\\Documents\\Embarcadero\\Studio\\Projects\\dictionary.txt", ios::app);
		if (dictFile.is_open()) {
			dictFile << "\n" << newWordStr; // Ensure each word is inserted on a new line
			dictFile.close();
			ShowMessage("Word \"" + newWord + "\" added to the dictionary.");
			ListBox1->Items->Add("Word count: " + IntToStr(word_count));
			ListBox1->Items->Add("Duplicate words skipped: " + IntToStr(duplicateCount));
		} else {
			ListBox1->Items->Add("Error opening dictionary file for writing!");
		}
	}

    // Clear the input box
	Input->Text = "";
    // Start the timer after loading the dictionary
    ClearListBoxTimer->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::ClearListBoxTimerTimer(TObject *Sender)
{
    // Clear the list box when the timer elapses
    ListBox1->Clear();
    // Disable the timer to prevent it from firing again
	ClearListBoxTimer->Enabled = false;
}
//---------------------------------------------------------------------------

